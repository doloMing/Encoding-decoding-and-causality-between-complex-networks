from .erdos_renyi import ErdosRenyiNetwork
from .watts_strogatz import WattsStrogatzNetwork
